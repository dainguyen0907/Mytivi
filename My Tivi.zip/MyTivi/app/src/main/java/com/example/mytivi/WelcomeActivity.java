package com.example.mytivi;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;

import java.util.ArrayList;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class WelcomeActivity extends AppCompatActivity {

    public String[] data;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_welcome);
            Methods methods = RetrofitClient.getRetrofitInstance().create(Methods.class);
            Call<ArrayList<Model>> call = methods.getChannelData(1);

            call.enqueue(new Callback<ArrayList<Model>>() {
                @Override
                public void onResponse(Call<ArrayList<Model>> call, Response<ArrayList<Model>> response) {
                    ArrayList<Model> schedules = response.body();
                    if (schedules.size() > 0) {
                        Bundle extra=new Bundle();
                        extra.putSerializable("schedules",schedules);
                        Intent intent=new Intent(WelcomeActivity.this,MainActivity.class);
                        intent.putExtra("schedules",extra);
                        startActivity(intent);
                        WelcomeActivity.this.finish();
                    }
                }

                @Override
                public void onFailure(Call<ArrayList<Model>> call, Throwable t) {
                    Log.d("error",t.getMessage());

                }

            });

    }
}