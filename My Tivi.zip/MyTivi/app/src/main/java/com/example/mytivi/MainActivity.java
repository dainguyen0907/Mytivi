package com.example.mytivi;

import androidx.appcompat.app.AppCompatActivity;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Intent;
import android.media.MediaPlayer;
import android.os.Bundle;

import android.util.Log;
import android.widget.VideoView;


import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;

public class MainActivity extends AppCompatActivity {

    private VideoView videoView;
    PendingIntent pendingIntent;
    AlarmManager alarmManager;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Bundle extra = getIntent().getBundleExtra("schedules");
        ArrayList<Model> schedules = (ArrayList<Model>) extra.getSerializable("schedules");

        videoView=this.findViewById(R.id.videoView);
        alarmManager = (AlarmManager) getSystemService(ALARM_SERVICE);

        try {
            String[] link=new String[schedules.size()];
            int[] t_start=new int[schedules.size()];
            String[]t_end=new String[schedules.size()];
            String[]time_start=new String[schedules.size()];


            SimpleDateFormat parser=new SimpleDateFormat("HH:mm:ss");
            Date now= Calendar.getInstance().getTime();
            int nowInSecond=now.getHours()*3600+now.getMinutes()*60;


            for(int i=0;i<schedules.size();i++)
            {
                link[i]=schedules.get(i).getLink_program();
                t_end[i]=schedules.get(i).getTime_end();
                time_start[i]=schedules.get(i).getTime_start();
                Date time_s=parser.parse(schedules.get(i).getTime_start());
                int time_startInSecond=time_s.getHours()*3600+time_s.getMinutes()*60;
                if(nowInSecond>time_startInSecond)
                {
                    t_start[i]= 0;
                }
                else
                {
                    t_start[i]= time_startInSecond-nowInSecond;
                }
            }

            int positionStart=findPositionTimeEnd(time_start);
            for(int i=positionStart;i<schedules.size();i++)
            {
                String li=link[i];
                alarmManager.setExact(AlarmManager.RTC_WAKEUP, Calendar.getInstance().getTimeInMillis()+(t_start[i]*1000), "TAG", new AlarmManager.OnAlarmListener() {
                    @Override
                    public void onAlarm() {
                        videoView.setVideoPath(li);
                        videoView.setOnPreparedListener(new MediaPlayer.OnPreparedListener() {
                            @Override
                            public void onPrepared(MediaPlayer mp) {
                                mp.setLooping(true);
                            }
                        });

                        videoView.start();
                    }
                },null);


            }
        } catch (ParseException e) {
            throw new RuntimeException(e);
        }

    }

    private int findPositionTimeEnd(String[] time_start)
    {
        int i=0;
        try {
            SimpleDateFormat parser=new SimpleDateFormat("HH:mm:ss");
            Date now= Calendar.getInstance().getTime();
            for(int p=0;p<time_start.length;p++)
            {
                Date t=parser.parse(time_start[p]);
                if((now.getHours()==t.getHours()&&now.getMinutes()<t.getMinutes())||(now.getHours()<t.getHours()))
                {
                    break;
                }
                i=p;
            }
        } catch (ParseException e) {
            Log.d("loi",e.getMessage());
            throw new RuntimeException(e);
        }
        return i;
    }


}