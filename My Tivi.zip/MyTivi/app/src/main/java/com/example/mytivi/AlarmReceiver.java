package com.example.mytivi;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.util.Log;
import android.widget.VideoView;

import androidx.appcompat.app.AppCompatActivity;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;

public class AlarmReceiver extends BroadcastReceiver {

    private VideoView videoView;
    @Override
    public void onReceive(Context context, Intent intent) {
        try {
            Bundle extra = intent.getExtras();
            String[] link= (String[]) extra.getSerializable("link");
            String[] time= (String[]) extra.getSerializable("time");

            SimpleDateFormat parser=new SimpleDateFormat("HH:mm:ss");
            Date now= Calendar.getInstance().getTime();

            for(int i=0;i<time.length;i++)
            {
                Date da=parser.parse(time[i]);
                if(da.getHours()==now.getHours()&&da.getMinutes()==now.getMinutes())
                {
                    videoView.setVideoPath(link[i]);
                    videoView.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
                        @Override
                        public void onCompletion(MediaPlayer mp) {
                            mp.setLooping(true);
                        }
                    });
                    videoView.start();
                    break;
                }

            }

        } catch (ParseException e) {
            throw new RuntimeException(e);
        }
    }

}
