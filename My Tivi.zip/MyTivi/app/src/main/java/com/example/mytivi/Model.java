package com.example.mytivi;


import java.io.Serializable;

public class Model implements Serializable {
    private int id_schedule;
    private int id_program;
    private String time_start;
    private String time_end;
    private int priority;
    private int id_catalogue;
    private String name_program;
    private String link_program;


    public int getId_schedule() {
        return id_schedule;
    }

    public int getId_program() {
        return id_program;
    }

    public String getTime_start() {
        return time_start;
    }

    public String getTime_end() {
        return time_end;
    }

    public int getPriority() {
        return priority;
    }

    public int getId_catalogue() {
        return id_catalogue;
    }

    public String getName_program() {
        return name_program;
    }

    public String getLink_program() {
        return link_program;
    }
}
